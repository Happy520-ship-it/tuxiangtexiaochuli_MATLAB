function out = small_process(image_in)
image = image_in;
image = image(1:2:end, 1:2:end,:);

out = image;

