function varargout = art_paper_cut_dlg(varargin)
% ART_PAPER_CUT_DLG M-file for art_paper_cut_dlg.fig
%      ART_PAPER_CUT_DLG, by itself, creates a new ART_PAPER_CUT_DLG or raises the existing
%      singleton*.
%
%      H = ART_PAPER_CUT_DLG returns the handle to a new ART_PAPER_CUT_DLG or the handle to
%      the existing singleton*.
%
%      ART_PAPER_CUT_DLG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ART_PAPER_CUT_DLG.M with the given input arguments.
%
%      ART_PAPER_CUT_DLG('Property','Value',...) creates a new ART_PAPER_CUT_DLG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before art_paper_cut_dlg_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to art_paper_cut_dlg_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help art_paper_cut_dlg

% Last Modified by GUIDE v2.5 12-Apr-2007 21:07:03

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @art_paper_cut_dlg_OpeningFcn, ...
                   'gui_OutputFcn',  @art_paper_cut_dlg_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before art_paper_cut_dlg is made visible.
function art_paper_cut_dlg_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to art_paper_cut_dlg (see VARARGIN)

% Choose default command line output for art_paper_cut_dlg
handles.output = hObject;
handles.image = getappdata(0, 'process_image');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes art_paper_cut_dlg wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = art_paper_cut_dlg_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function degree_slider_Callback(hObject, eventdata, handles)
% hObject    handle to degree_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
degree = round(get(hObject,'Value'));
degree = max(0, degree);
degree = min(255, degree);

set(handles.degree_edit, 'String', num2str(degree));

image = handles.image;
image = art_paper_cut_process(image, degree);
setappdata(0, 'process_image', image);
show_origin_image;

% --- Executes during object creation, after setting all properties.
function degree_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to degree_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function degree_edit_Callback(hObject, eventdata, handles)
% hObject    handle to degree_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of degree_edit as text
%        str2double(get(hObject,'String')) returns contents of degree_edit as a double


% --- Executes during object creation, after setting all properties.
function degree_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to degree_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on button press in sure_pushbutton.
function sure_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to sure_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(handles.figure1);

% --- Executes on button press in cancel_pushbutton.
function cancel_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to cancel_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
setappdata(0, 'process_image', handles.image);
show_origin_image;
delete(handles.figure1);

