function out = pencil_process(image_in, degree)
image = gray_process(image_in, 4);
threshold = degree / 255;

[h,w,z] = size(image);
image_new = zeros(h,w,z);

for i=2:1:h-1
    for j=2:1:w-1
        pixel = image(i-1,j-1,1) + image(i-1,j,1) + image(i-1,j+1,1) + image(i,j-1,1)...
            + image(i,j+1,1) + image(i+1,j-1,1) + image(i+1,j,1) + image(i+1,j+1,1);
        pixel = pixel / 8;
        
        r = abs(image(i,j,1) - pixel);
        if r > threshold
            image_new(i,j,:) = [0 0 0]; 
        else
            image_new(i,j,:) = [1 1 1];
        end
    end
end

out = image_new;